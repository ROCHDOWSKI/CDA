<?php
session_start();

// DEBUG (à garder pendant le développement)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexion DB
require __DIR__ . '/app/connect.php';

// Génération CDA
require __DIR__ . '/CDA/generate_cda.php';

// Récupérer IDs existants
$query = $pdo->prepare('SELECT IDpat FROM patient');
$query->execute();
$existingIds = $query->fetchAll(PDO::FETCH_COLUMN);

if (isset($_POST['enregistrer'])) {

    // ======================
    // ID PATIENT UNIQUE
    // ======================
    do {
        $cin = uniqid();
    } while (in_array($cin, $existingIds));

    // ======================
    // DONNÉES FORMULAIRE
    // ======================
    $nom        = trim($_POST['nom']);
    $prenom     = trim($_POST['pnom']);
    $numtel     = trim($_POST['numtel']);
    $datenaiss  = trim($_POST['datenaiss']);

    $diagnostique = !empty($_POST['diagnostique'])
        ? trim($_POST['diagnostique'])
        : 'Pas de diagnostique';

    $address = !empty($_POST['adress'])
        ? trim($_POST['adress'])
        : 'Pas d\'adresse';

    // ======================
    // VALIDATION MINIMALE
    // ======================
    if (!$nom || !$prenom || !$numtel || !$datenaiss) {
        die('❌ Champs obligatoires manquants');
    }

    // ======================
    // INSERT PATIENT
    // ======================
    $insert = $pdo->prepare("
        INSERT INTO patient 
        (IDpat, IDmed, prenom, nom, datenai, address, numtel, diagnostique, correspondance)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, '')
    ");

    $insert->execute([
        $cin,
        $_SESSION['id'],   // ID médecin connecté
        $prenom,
        $nom,
        $datenaiss,
        $address,
        $numtel,
        $diagnostique
    ]);

    // ======================
    // DOSSIERS PATIENT
    // ======================
    $folder = 'data/patients/document/' . $cin;

    // ======================
    // GÉNÉRATION AUTOMATIQUE CDA
    // ======================
    $patientData = [
        'IDpat' => $cin,
        'prenom' => $prenom,
        'nom' => $nom,
        'datenai' => $datenaiss,
        'diagnostique' => $diagnostique
    ];

    $cdaUrl = generateCDA($patientData, $folder);

    // ======================
    // MISE À JOUR BDD
    // ======================
    $upd = $pdo->prepare(
        'UPDATE patient SET correspondance = ? WHERE IDpat = ?'
    );
    $upd->execute([$cdaUrl, $cin]);

    // ======================
    // REDIRECTION
    // ======================
    header('Location: patient.php?id_patient=' . $cin);
    exit;
}

// Affichage template
$title = 'Ajouter Patient';
$template = 'add';
include 'layout.phtml';
