# Solution-challenge-Smart-DPU-GDSC-ISTMT
# install wamp or wampp
# clone the repository in the root directory of the serve 
# create a data base in the MySQL server using phpMyadmin
# import database from database.sql file from the repository
# Configure ./app/connect.php file with your configurations
# install node js
# in the root directory of the app open terminal and type npm install
# to run the app go via http://localhost/your_directory_name_in_the_server_root
