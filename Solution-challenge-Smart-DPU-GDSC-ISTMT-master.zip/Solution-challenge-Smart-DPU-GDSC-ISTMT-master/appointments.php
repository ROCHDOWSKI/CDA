<?php
require_once 'app/connect.php';

// ==========================
// SUPPRESSION RDV
// ==========================
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM appointments WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: appointments.php?deleted=1");
    exit;
}

// ==========================
// LISTE DES RDV
// ==========================
$stmt = $pdo->query("
    SELECT 
        a.id,
        a.date_rdv,
        a.time_rdv,
        a.note,
        p.nom AS pnom,
        p.prenom AS pprenom,
        m.nom AS mnom,
        m.prenom AS mprenom
    FROM appointments a
    JOIN patient p ON a.patient_id = p.IDpat
    JOIN medecin m ON a.doctor_id = m.ID
    ORDER BY a.date_rdv DESC, a.time_rdv DESC
");

$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Rendez-vous</title>

    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f4f6f9;
        }
        .table td, .table th {
            vertical-align: middle;
        }
    </style>
</head>
<body>

<div class="container mt-5">

    <!-- TITRE -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>📋 Gestion des Rendez-vous</h3>
        <a href="add_rdv.php" class="btn btn-primary">
            ➕ Nouveau rendez-vous
        </a>
    </div>

    <!-- ALERTES -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">✔ Rendez-vous ajouté avec succès</div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-danger">🗑️ Rendez-vous supprimé</div>
    <?php endif; ?>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-body">

            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>Patient</th>
                        <th>Médecin</th>
                        <th>Date</th>
                        <th>Heure</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php if (count($appointments) === 0): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Aucun rendez-vous trouvé
                        </td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($appointments as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['pnom'].' '.$a['pprenom']) ?></td>
                        <td><?= htmlspecialchars($a['mnom'].' '.$a['mprenom']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($a['date_rdv']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($a['time_rdv']) ?></td>
                        <td><?= htmlspecialchars($a['note']) ?></td>
                        <td class="text-center">
                            <a href="appointments.php?delete=<?= $a['id'] ?>"
                               class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Supprimer ce rendez-vous ?');">
                                🗑️
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                </tbody>
            </table>

        </div>
    </div>

</div>

</body>
</html>
