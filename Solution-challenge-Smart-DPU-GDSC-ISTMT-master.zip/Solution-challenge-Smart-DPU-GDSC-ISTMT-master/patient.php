<?php
session_start();
require_once 'app/connect.php';

// Récupérer tous les patients
$stmt = $pdo->query("SELECT * FROM patient ORDER BY nom");
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Patients</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background:#f4f6f9; }
        .table td, .table th { vertical-align: middle; }
    </style>
</head>
<body>

<div class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>👥 Liste des Patients</h3>
        <a href="add.php" class="btn btn-primary">➕ Ajouter patient</a>
    </div>

    <div class="card shadow">
        <div class="card-body">

            <table class="table table-bordered table-hover">
                <thead class="table-dark text-center">
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Date naissance</th>
                        <th>Téléphone</th>
                        <th>CDA</th>
                    </tr>
                </thead>
                <tbody>

                <?php foreach ($patients as $p): ?>
                    <tr>
                        <td><?= htmlspecialchars($p['nom']) ?></td>
                        <td><?= htmlspecialchars($p['prenom']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($p['datenai']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($p['numtel']) ?></td>

                        <!-- ✅ COLONNE CDA CORRIGÉE -->
                        <td class="text-center">
                            <?php if (!empty($p['correspondance'])): ?>
                                <a href="<?= htmlspecialchars($p['correspondance']) ?>"
                                   target="_blank"
                                   class="btn btn-sm btn-success">
                                    📄 Voir CDA
                                </a>
                            <?php else: ?>
                                <span class="badge bg-secondary">
                                    Aucun CDA
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

                </tbody>
            </table>

        </div>
    </div>

</div>

</body>
</html>
