<?php

function generateCDA($patient, $folder)
{
    // Création XML CDA
    $xml = new SimpleXMLElement('<ClinicalDocument/>');
    $xml->addAttribute('xmlns', 'urn:hl7-org:v3');

    // Identifiant du document
    $xml->addChild('id')->addAttribute('root', uniqid());

    // ======================
    // SECTION PATIENT
    // ======================
    $recordTarget = $xml->addChild('recordTarget');
    $patientRole = $recordTarget->addChild('patientRole');
    $patientRole->addChild('id')->addAttribute('extension', $patient['IDpat']);

    $p = $patientRole->addChild('patient');
    $name = $p->addChild('name');
    $name->addChild('given', $patient['prenom']);
    $name->addChild('family', $patient['nom']);

    $p->addChild('birthTime')->addAttribute(
        'value',
        str_replace('-', '', $patient['datenai'])
    );

    // ======================
    // SECTION MÉDICALE
    // ======================
    $component = $xml->addChild('component');
    $body = $component->addChild('structuredBody');
    $section = $body->addChild('component')->addChild('section');

    $section->addChild('title', 'Résumé médical');
    $section->addChild(
        'text',
        htmlspecialchars('Diagnostique : ' . $patient['diagnostique'])
    );

    // ======================
    // SAUVEGARDE DU FICHIER
    // ======================
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    $relativePath = $folder . '/patient_' . $patient['IDpat'] . '.xml';
    $xml->asXML($relativePath);

    // ======================
    // URL ABSOLUE (IMPORTANT)
    // ======================
    $baseUrl = 'http://localhost/Solution-challenge-Smart-DPU-GDSC-ISTMT-master/';
    $absoluteUrl = $baseUrl . $relativePath;

    // On retourne L’URL (pas le chemin)
    return $absoluteUrl;
}
